package com.expensetracker.controller;

public class ApiExceptionHandler {

}
