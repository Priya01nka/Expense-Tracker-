package com.expensetracker.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expensetracker.model.Expense;
import com.expensetracker.model.User;
import com.expensetracker.repository.ExpenseRepository;
import com.expensetracker.service.ExpenseService;

@Service
public class ExpenseServiceImpl implements ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Override
    public Expense saveExpense(Expense expense) {
        return expenseRepository.save(expense);
    }

    @Override
    public List<Expense> getExpensesByUser(User user) {
        return expenseRepository.findByUser(user);
    }
    @Override
    public Expense getExpenseById(Long id, User user) {
        return expenseRepository.findById(id)
                .filter(exp -> exp.getUser().getId().equals(user.getId()))
                .orElse(null);
    }

    @Override
    public void deleteExpense(Long id, User user) {
        expenseRepository.findById(id).ifPresent(exp -> {
            if (exp.getUser().getId().equals(user.getId())) {
                expenseRepository.delete(exp);
            }
        });
    }
    
}
