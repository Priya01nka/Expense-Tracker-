package com.expensetracker.controller;

import java.util.List;  // ✅ import List

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.expensetracker.model.Expense;
import com.expensetracker.model.User;      // ✅ import User
import com.expensetracker.service.ExpenseService;
import com.expensetracker.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class DashboardController {

    @Autowired
    private UserService userService;

    @Autowired
    private ExpenseService expenseService;

    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session, Model model) {
        User sessionUser = (User) session.getAttribute("loggedInUser");

        if (sessionUser == null) {
            model.addAttribute("error", "Please login first.");
            return "login";
        }

        // ✅ fetch managed User entity from DB
        User dbUser = userService.findByUsername(sessionUser.getUsername());

        // ✅ now this will return actual expenses
        List<Expense> expenses = expenseService.getExpensesByUser(dbUser);

        System.out.println("Found " + expenses.size() + " expenses for user " + dbUser.getUsername());

        model.addAttribute("username", dbUser.getUsername());
        model.addAttribute("expenses", expenses);

        return "dashboard";
    }
}

